package com.desafio.projuris.projuris;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjurisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjurisApplication.class, args);
	}

}
