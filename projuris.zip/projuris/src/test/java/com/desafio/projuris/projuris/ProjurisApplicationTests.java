package com.desafio.projuris.projuris;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjurisApplicationTests {

	@Test
	void contextLoads() {
	}

}
